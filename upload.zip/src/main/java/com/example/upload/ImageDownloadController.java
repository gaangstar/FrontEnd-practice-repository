package com.example.upload;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
public class ImageDownloadController {

    // 이미지를 다운로드 받도록 하는 엔드포인트
    @GetMapping("/display/{filename}")
    public ResponseEntity<Resource> downloadImage(@PathVariable String filename) {
        try {
            // static/uploads 폴더에서 이미지 경로
            Path imagePath = Paths.get("src/main/resources/static/uploads").resolve(filename);

            // 파일 리소스를 로드
            Resource resource = new UrlResource(imagePath.toUri());

            // 파일이 존재하고 읽을 수 있는지 확인
            if (resource.exists() || resource.isReadable()) {
                // 이미지 다운로드 응답
                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)  // 이미지 형식 설정 (예: JPG)
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();  // 파일을 찾을 수 없는 경우 404 응답
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();  // 오류 발생 시 500 응답
        }
    }
}
